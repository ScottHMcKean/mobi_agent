# Community Pass - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/community-pass
**Description:** 
**Main Heading:** 
**Scraped:** 2025-11-10 22:46:46

---

Our Community Pass program, first launched in 2018, makes bike share more accessible and affordable. Now even more people can enjoy the benefits of biking in Vancouver through discounted memberships and cash payment options.

#### You may qualify for this pass if you have a:

\*No credit card required. Cash, debit and e-transfer available.

- ##### 1

  Leisure Access Pass
- ##### 2

  Red Compass Card
- ##### 3

  Greater Vancouver Food Bank Membership
- ##### 4

  Proof of Annual Income Less Than $38,000
- ##### 5

  Third Party Referral from a Community Partner
- ##### 6

  A Persons With Disabilities Designation

![](https://storage.googleapis.com/mobi-customer-website/placeholder_Mobi_David_Niddrie_Photo_Dec2023_High_Res_6329_1_4f9f8a6b17/placeholder_Mobi_David_Niddrie_Photo_Dec2023_High_Res_6329_1_4f9f8a6b17.jpg)

### Applying for the first time?

#### Community Pass

Includes unlimited 60-minute rides on Classic Bikes ONLY!

- Classic Bikes: Unlimited 60-minute rides, $0.25/min thereafter
- Ebikes: NO ACCESS

[Apply](https://docs.google.com/forms/d/e/1FAIpQLSelVv7lmwppyGPgF3l6HzrQVHWwJjHi89e-C24Vunc4bJxa1A/viewform)

Details

Classic Bikes – $0.25/minute if you exceed the 60-minute ride limit
No Ebike Access

#### Community Pass (Ebike)

Includes unlimited 60-minute rides on Classic Bikes. Ebikes available for $0.35.

- Classic Bikes: Unlimited 60-minute rides, $0.25/min thereafter
- Ebikes: $0.15/min for the first 60 minutes, $0.35/min thereafter
- Credit card required.

[Apply](https://docs.google.com/forms/d/e/1FAIpQLSelVv7lmwppyGPgF3l6HzrQVHWwJjHi89e-C24Vunc4bJxa1A/viewform)

Details

This pass requires a credit card on file.
Classic Bikes – $0.25/minute if you exceed the 60-minute ride limit.
Ebikes – $0.35/min

#### Community Pass (PWD)

Includes unlimited 60-minute rides on both Classic Bikes & Ebikes.

- Classic Bikes: Unlimited 60-minute rides, $0.25/min thereafter.
- Ebikes: Unlimited 60-minute rides, $0.35/min thereafter

[Apply](https://docs.google.com/forms/d/e/1FAIpQLSelVv7lmwppyGPgF3l6HzrQVHWwJjHi89e-C24Vunc4bJxa1A/viewform)

Details

Classic Bikes – $0.25/minute if you exceed the 60-minute ride limit.
Ebikes – $0.35/minute if you exceed the 60-minute ride limit.
Requires proof of PWD designation

#### Community Pass (Youth)

Includes unlimited 60-minute rides on Classic Bikes ONLY!

- Classic Bikes: Unlimited 60-minute rides, $0.25/min thereafter
- Ebikes: NO ACCESS

[Apply](https://forms.gle/stZVdr2AtCvnS7Zn6)

Details

Classic Bikes – $0.25/minute if you exceed the 60-minute ride limit
No Ebike Access

### Renewing your pass?

#### Community Pass (Classic, Ebike, or PWD)

Apply here if you already have a Community Pass (Classic, Ebike, or PWD) and want to renew.

[Renew Pass](https://forms.gle/ZuNrHNmPivcS4vVS8)

Details

You will be required to re-submit your eligibility, to ensure it's up to date.

#### Community Pass Youth

Apply here if you already have a Community Pass (Youth) and want to renew.

[Renew Pass](https://forms.gle/mo2fr8iQgwcv1fC78)

Details

You will be required to re-submit your eligibility, to confirm it's up to date.
Student ID from a participating Secondary School Required