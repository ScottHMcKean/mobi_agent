# Our company - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/our-company
**Description:** 
**Main Heading:** 
**Scraped:** 2025-11-10 22:46:40

---

Vancouver Bike Share Inc (Mobi by Rogers) is a public bike sharing service based in Vancouver, British Columbia. It is perfect for commuting, running errands, visiting friends, or exploring the city. Serving Vancouver with 2,000 classic bikes and 600 ebikes at 250+ stations, our bike share system has become an essential part of our transportation network.

Our bikes are available for use 24/7 year-round and can be unlocked from one station and returned to any other station within our system, making them ideal for one-way trips – without the hassle of worrying about maintenance or bike theft.

In partnership with the City of Vancouver, Mobi by Rogers is part of the City’s vision of promoting cycling as an integral part of daily life.

Now in our 9th year of operations out of our East Vancouver warehouse, Mobi by Rogers employs 60+ people in Vancouver and its surrounding areas as a certified Living Wage employer in British Columbia!

We are committed to providing our city and region with a seamless, efficient, affordable, and exceptionally-serviced bike share and ebike share system.

We offer an alternative and innovative mode of personal transportation in bike share – which we strongly believe will support the decarbonization of urban transport while providing co-benefits for public health. 

We pride ourselves on the impact Mobi by Rogers has had on reducing GHGs and air pollution, as well as in our role in increasing accessibility of underrepresented communities, promotion of equity in mobility, and improvement of personal health – all of which are demonstrated in the ways we work with our community. 

Our Community Pass Program was specifically created to remove barriers to accessing bike share and has provided more than 1,500 Vancouverites with access to bike share at a fraction of the cost – when they may otherwise not have been able to afford it. 

We continuously work with community partners who support low-income, disabled, and underrepresented groups to provide these individuals with bike share and ensure that we’re keeping equity as a core value as we grow.

Mobi by Rogers operates on the ancestral and unceded territories of the xʷməθkwəy̓əm (Musqueam), Skwxwú7mesh (Squamish), and Səl̓ílwətaɬ (Tsleil-Waututh) Nations, who have inhabited these lands for thousands of years. We honour the ancestry of these lands, understand it's our responsibility to learn about Indigenous cultures here and across Canada, and pay our respect to the original peoples and stories of this territory we call home.