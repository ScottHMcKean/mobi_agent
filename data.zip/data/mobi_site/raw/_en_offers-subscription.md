# Pricing - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/offers-subscription
**Description:** 
**Main Heading:** 
**Scraped:** 2025-11-10 22:46:27

---

### Passes

#### PAY PER RIDE

Pay by the minute. Great for infrequent, short trips.

- Classic Bikes: $1.00 to unlock + $0.29/min
- Ebikes: $1.75 to unlock + $0.39/min

[Subscribe](/profile)

Conditions

– Access up to (4) bikes. Rates apply to each bike taken
– All charges subject to tax.

#### MONTHLY PASS – $49

Unlimited 30-minute rides on classic bikes in a 30-day period.

- Classic Bikes: Unlimited 30-minute rides, $0.29/min thereafter
- Ebikes: $0.29/min

[Subscribe](/profile)

Conditions

Auto-renews every 30 days
All charges subject to tax

#### ANNUAL PASS – $169

Unlimited 60-minute rides on classic bikes in a one-year period.

- Classic Bikes: Unlimited 60-minute rides, $0.29/min thereafter.
- Ebikes: $0.19/min

[Subscribe](/profile)

Conditions

Auto-renews every year
All charges subject to tax

#### UBC EBIKE PASS – $149

This pass is only available to eligible UBC students, faculty, & staff. You are required to submit your eligibility for review.

- Unlimited 60-minute rides on Classic & Ebikes, $0.29/min thereafter.
- Only available to UBC students, faculty, & staff.
- Students required to submit copy of Enrolment Letter
- Faculty & Staff to submit copy of Letter of Employment

[Learn More](/en/ubc)

Conditions

Pass does NOT automatically renew.
All charges subject to tax

### Community Pass

![](https://storage.googleapis.com/mobi-customer-website/placeholder_J_Fq_Vgglg_1_8350761c7e/placeholder_J_Fq_Vgglg_1_8350761c7e.jpg)

### Ride More, Pay Less – Just $20/Year!

Get unlimited 60-minute Mobi rides with the Community Pass, designed for eligible Vancouver residents. No credit card needed.

[Learn more!](/en/community-pass)

### Get the Mobi app

Download the Mobi app to find available bicycles and docking stations around town. New members can sign up through the app as well.