# Local Bike shops - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/local-bike-shops
**Description:** 
**Main Heading:** 
**Scraped:** 2025-11-10 22:46:54

---

Riding with a family?  Riding for more than an hour?  If yes, we encourage you to visit one of our many bike rental locations listed below. [Search for bike rentals in Vancouver on google.](https://www.google.ca/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=local%20bike%20rentals)

### **Vancouver Bike Rentals**

**Bayshore Bicycle Rentals**

745 Denman St

604 688-2453

**Bike Doctor**

137 W Broadway

604 873-2453

**Bicycles Sports Pacific**  
999 Pacific Street  
604 682 4537  
  
1387 Hornby Street  
604 682 4537  
  
**Bikes N' Blades Rental**

718 Denman St

604 602-9899

**Bike Rental**

708 Denman St

**Bikes for All**

112 E 7th Avenue

604 872-4534

**Bikes on Robson**

1531 Robson St

778 371-7316

**Cycle BC Rentals + Tours**

73 E 6th Avenue

604 709-5663

**Cycle City Tours and Rentals**

1344 Burrard St

604 618-8626

**Cycle City Tours and Rentals**

648 Hornby St

604 618-8626

**English Bay Bike Rentals**

1754 Davie St

604 568-8490

**EzeeRiders Seawall**

1055 Canada Place

604 331-1789

**EzeeRiders on Robson**

1823 Robson St

604 331-1789              
  
**JV Bike**  
929 Expo Blvd  
  
**More bikes**  
1856 West 4th  
Vancouver, BC  
778-379-9168

**Reckless: Fir**

1810 Fir St

604 731-2420

**Reckless: Davie**

110 Davie St

604 648-2600

**Seawall Adventure Centre**

1075 W Waterfront Rd

604 233-3500

**Simon's Bike Shop**

608 Robson St

604 602-1181

**Spokes Bicycle Rental**

1798 W Georgia St

604 688-5141

**Stanley Park Cycle**

768 Denman St

604 688-0087

**Union Street Cycles**  
247 Union Street  
604 255 5097

**Urban Waves**

#210 510 Nicola St

604 259-9526      

**Vancouver Bike Tours**

1754 Davie St

778 628-4316    

**Yes Cycle**

687 Denman St

604 569-0088

**Zap Bike Rentals**

1680 Robson St

604 558-1680