# Grab a bike, explore Vancouver - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/sharing
**Description:** 
**Main Heading:** Get the Mobi app
**Scraped:** 2025-11-10 22:46:25

---

### How it works

#### First time?

- ##### 1

  Create your account on the app or the website
- ##### 2

  Select your desired plan and enter your credit card information
- ##### 3

  You will be assigned a User Code to access the bikes. This code will always be displayed in your profile.
- ##### 4

  Head over to a station to start a ride!

[Create my account](/profile/auth)

![](https://storage.googleapis.com/mobi-customer-website/placeholder_bis_58f8ed436f/placeholder_bis_58f8ed436f.png)

#### Ready to start ?

- ##### 1

  Use the app to find your nearest station, and head on over
- ##### 2

  Press "Enter" to wake the bike and follow the prompts
- ##### 3

  Enter your 7-digit User Code followed by your 4-digit PIN code
- ##### 4

  Push cable into handlebar and remove your bike.
- ##### 5

  Enjoy your ride!

![](https://storage.googleapis.com/mobi-customer-website/placeholder_Mobi_David_Niddrie_Photo_Dec2023_High_Res_5992_1_31e8a13b2c/placeholder_Mobi_David_Niddrie_Photo_Dec2023_High_Res_5992_1_31e8a13b2c.jpg)

#### Making a stopover?

Making a quick stop? You can lock the bike using the integrated cable — but remember, your trip time keeps running, so a docking station is always best when possible.

- ##### 1

  Press “Enter” and scan your card or enter your PIN
- ##### 2

  Press the button on the end of the left handlebar to release the cable lock on the right handlebar
- ##### 3

  Lock the bike to a secure spot by inserting the cable into the tube above the front wheel

![](https://storage.googleapis.com/mobi-customer-website/placeholder_Tt5_Fyxpw_a7ce343b1d/placeholder_Tt5_Fyxpw_a7ce343b1d.jpeg)

#### Returning your bike

You can return your bike at any station with an available dock.
Follow these steps:

- ##### 1

  Insert the front tire into any available dock
- ##### 2

  Firmly push the bike into the dock
- ##### 3

  Wait for the 'BEEP' and a 'RIDE ENDED' message to display on the screen.
- ##### 4

  If you do not receive a notification, press the ENTER button on the keypad and re-insert it into the dock.

![](https://storage.googleapis.com/mobi-customer-website/placeholder_Mobi_David_Niddrie_Photo_Dec2023_High_Res_6329_1_4f9f8a6b17/placeholder_Mobi_David_Niddrie_Photo_Dec2023_High_Res_6329_1_4f9f8a6b17.jpg)

### How to register, ride & return

## Get the Mobi app

Download the Mobi by Rogers app to find available bikes and docking stations around town.

[![Download link for the application on App Store](/images/badges/app-store/en.svg)](https://apps.apple.com/app/mobi-by-rogers/id1076524221)[![Download link for the application on Play Store](/images/badges/play-store/en.png)](https://play.google.com/store/apps/details?id=com.choosit.smoove)

![](https://storage.googleapis.com/mobi-customer-website/placeholder_Frame_14369_46755b5ed3/placeholder_Frame_14369_46755b5ed3.png)