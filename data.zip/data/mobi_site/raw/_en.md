# Vancouver Bike Share - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/#blocks-banner
**Description:** Rogers and Mobi by Rogers provide Vancouver with an easy, convenient, and fun way to get around and explore our beautiful city!
**Main Heading:** 
**Scraped:** 2025-11-10 22:46:44

---

![](https://storage.googleapis.com/mobi-customer-website/map_preview_desktop_b717a63b7e/map_preview_desktop_b717a63b7e.jpg)

#### Find a Bike

[Open Map](/en/map)

![](https://storage.googleapis.com/mobi-customer-website/Mobi_David_Niddrie_Photo_Dec2023_High_Res_5684_1_e334000d78/Mobi_David_Niddrie_Photo_Dec2023_High_Res_5684_1_e334000d78.jpg)

#### Pricing

[Choose a plan](/en/offers-subscription)

![](https://storage.googleapis.com/mobi-customer-website/placeholder_p18l_PGOA_1_1_1_02d33c3e87/placeholder_p18l_PGOA_1_1_1_02d33c3e87.jpg)

### Introducing Mobi by Rogers!

Vancouver Bike Share is proud to have Rogers as our system-wide presenting partner of Mobi by Rogers. With common values and practices, connectivity, and smart technology, Rogers and Mobi by Rogers provide Vancouver with an easy, convenient, and fun way to get around and explore our beautiful city!