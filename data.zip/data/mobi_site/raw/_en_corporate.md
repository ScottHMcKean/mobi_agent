# Corporate Membership Program - Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/corporate
**Description:** 
**Main Heading:** Give Your Team the Power to Ride—at a Discount
**Scraped:** 2025-11-10 22:46:50

---

## Give Your Team the Power to Ride—at a Discount

Mobi by Rogers makes it easy for companies to support sustainable commuting and healthy lifestyles. For a one-time annual fee of just **$500**, your organization can join our Corporate Program, unlocking access to discounted Mobi memberships for all employees.

Instead of the regular $169 annual pass, your employees pay only $119 for a year's access to bike share!

By joining, your company supports:

- **Active, healthy commuting**
- **Lower transportation costs for staff**
- **Environmental sustainability and reduced congestion**
- **Employee wellness and morale**

Join dozens of forward-thinking Vancouver employers who are helping their teams get around the city more affordably and responsibly.

### Are you looking to enrol your company in the Corporate Program?

[Company enrolment](https://docs.google.com/forms/d/e/1FAIpQLSeOkCSM4kCecQh1jLxqarv4ny5JZU2Es6gvyGX_asFY5e4DhA/viewform)

#### Is your company already enrolled?

- ##### 1

  Download the Mobi by Rogers App
- ##### 2

  Sign up for an account
- ##### 3

  Go to the Wallet section
- ##### 4

  Enter your company promo code
- ##### 5

  Enjoy your ride!

[Download the app now!](https://www.mobibikes.ca/en/app)

![](https://storage.googleapis.com/mobi-customer-website/placeholder_Mobi_David_Niddrie_Photo_July2024_High_Res_3208_copy_d7896211cd/placeholder_Mobi_David_Niddrie_Photo_July2024_High_Res_3208_copy_d7896211cd.jpeg)