# Mobi by Rogers

**URL:** https://www.mobibikes.ca/en/refund-policy
**Description:** 
**Main Heading:** 
**Scraped:** 2025-11-10 22:46:31

---

### Vancouver Bike Share Inc. Refund Policy

**POLICY LAST UPDATED: April 2, 2024**  
   
PLEASE READ THESE TERMS AND CONDITIONS OF USE CAREFULLY BEFORE RENTING OR USING A BICYCLE (“BIKE”) FROM VANCOUVER BIKE SHARE INC. AND CYCLEHOP, LLC DBA MOBI BIKE SHARE, OR ANY OF THEIR AFFILIATES (COLLECTIVELY, "VBS"), VBS AND SMOOVE SAS. ARE JOINTLY REFERENCED HEREIN AS "OPERATOR".  
   
SECTION 1. FOUNDING MEMBER REFUNDS  
This section applies to Riders who signed up for a membership before July 20, 2016. In the event your circumstances change before the date that Operator makes Bikes available to the public for rental (“Launch Date”) you may request a refund of your membership (excluding the value of promotional items) by contacting info@mobibikes.ca.  
   
SECTION 2. SERVICE LIMITATIONS.  
Rider acknowledges and agrees that from and after the Launch Date, Operator may suspend all or part of its Bike Share Program at any time, may relocate Stations, reduce the number of Bikes available for rent and otherwise operate its Bike rental program in its sole discretion. Station locations and system size are subject to change without notice. Such a change will not qualify Riders for a refund. No refunds will be issued following Launch Date unless criteria meets that of Section 4 and is approved by Operator.  Rider further acknowledges that Operator may suspend the availability of Bikes during adverse weather conditions, or may be required to suspend the rental of Bikes by the municipality in which the Bikes are located. Rider shall not be entitled to a refund of any fees for unused rental periods unless Operator’s Bike rental service shall have been suspended for a total of more than 15 calendar days over the course of a twelve month period. Operator does not represent or warrant that Bikes will be available for rental at any Station at any time. Operator may require the return of its Bikes at any time.  
   
SECTION 3. TERMINATION OF AGREEMENT.  
Operator may terminate this Agreement at any time, without cause, legal process, or notice to the Rider and Rider’s use of the Bike Share Program is “at the will” of Operator. Rider waives all claims, causes of actions, expenses, and/or damages connected and/or related to any such termination. Rider shall not be entitled to a refund of any amount paid for unused rental periods if this Agreement is terminated for cause. Rider may terminate Rider’s rental plan at any time; provided, however, that no refund will be provided by Operator for time already used or not used by Rider as described in Section 4: Payments, cancellations, and “Cooling-off”.  
  
SECTION 4. PAYMENTS, CANCELLATIONS, AND ‘COOLING OFF’  
When you (“Rider”) subscribe to a membership plan or pass, under a Promotional agreement or not, you consent to access the Bikes. Any Rider may change their mind for any or no reason and receive a full refund of all monies paid within fourteen (14) days of such payment (the “Cooling-off Period”). Refunds will not, however, be provided if you have used a Bike at any time during the Cooling-off Period. The Cooling-off Period is defined as starting upon the first membership payment in question; any subsequent automatically renewed memberships will not reset the Cooling-off Period and are not eligible for a refund. After the Cooling-off Period has passed and if no Bikes have been used under such membership, Rider may request a refund at the discretion of Operator. Refunds may be provided no later than 4 months after purchase date.  
  
Unless registered as a Pay Per Ride, UBC Ebike Pass, or Community Pass user, your subscription will automatically renew at the end of the subscription period, unless you cancel your membership before the end of the current subscription period. The cancellation will take effect immediately. The Rider may request to turn off their subscription auto-renew by contacting Customer Service at [info@mobibikes.ca](mailto:info@mobibikes.ca) or 778-655-1800; once turned off, the membership will expire the day after the last day of the current subscription period. However, if you cancel your payment or your membership and/or terminate any of the Agreements (1) after you have used a Bike during the Cooling-off Period, or (2) after the Cooling-off Period is over (where applicable), or (3) before the end of the current subscription period, the Rider shall not be entitled to a refund of any fees already paid to the Operator.  
  
SECTION 4.1. Overage Fees  
Refunds will not be provided for overage fees as defined in 2.4 of Operator Terms and Conditions. This includes, but is not limited to, overages due to: failure to attempt to properly dock Bikes at stations within the plan’s allotted time, and improperly locked Bikes.  
  
SECTION 5. REFUNDS AND PROMOTIONS  
From time to time, the Operator, or others on our behalf (ie Groupon), may offer trials of paid passes or plans for a specified period without payment or at a reduced rate (a “Trial”). The Operator reserves the right, in its absolute discretion, to determine your eligibility for a Trial, and, subject to applicable laws, to withdraw or to modify a Trial at any time without prior notice and with no liability, to the greatest extent permitted under the law. If a relevant trial or promotional code is not applied at the time of purchase, Rider may not retroactively apply a promotion code to fees already paid to Operator and will not eligible for a refund.  
  
For certain Trials, we will require you to provide your payment details to start the Trial. At the end of such Trial, we may automatically start to charge you for the applicable paid subscription on the first day following the end of the Trial, on a recurring basis (monthly, annual, or as otherwise determined). By providing your payment details in conjunction with the Trial, you agree to this charge using such payment method details. If you do not want to continue to be charged on a recurring basis you must cancel the applicable paid subscription or terminate your account with the Operator before the end of the recurring monthly or annual period. The Operator will not refund any fees that you have already paid.